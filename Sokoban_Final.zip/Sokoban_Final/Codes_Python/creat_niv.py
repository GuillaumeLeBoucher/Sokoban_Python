# -*- coding: utf-8 -*-
"""
Created on Fri May 18 02:13:32 2018

@author: guillaume
"""
from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys

from create import *
from Plateau_Jeu import *
from Joueur import *

"""
La Classe Creat(),qui hérite de la classe Ui_create fournie par Qt Designer, est la
classe qui va nous permettre d'éditer un niveau. Son fonctionnement est relativement
simple car elle reprends le principe du mode histoire (le jeu). En effet, on créer 
tout d'abord une grille d'une certaine taille (fichier texte déjà initialisés à la 
bonne taille) puis on vient y inserer les composants (joueur, caisse, goal...).

Pour ce faire, on créer des boutons pour chaque composants et en cliquant dessus on
va modifier la valeur de la variable choix_composant. Ensuite, en fonction de la 
valeur de cette variable, on va à l'aide du clique gauche de la souris venir les 
placer sur la grille. Pour cela il nous faut une méthode mousePressEvent pour utiliser
la souris. Ensuite on va venir chercher les coordonnées du click de la souris sur 
l'écran avec x.event() et y.event(). Avec ces coordonnées et un petit calcul, on 
détermine quelle case de la grille le joueur veut modifier et on la modifie alors
en fonction du choix du composant.

On limte à un joueur sans quoi on ne pourrait pas jouer. Le reste est laisser à 
l'imagination du Joueur. 

Enfin dès lors qu'on appuie dur le bouton Play on rentre dans la phase de Jeu et ne 
peut plus modifier le plateau à moins de charger une nouvelle grille.
La phase de Jeu se déroule exactement comme celle du mode histoire. 
"""
class Creat(QMainWindow,Ui_create):
    nbr_pas=0 #Compteur de pas pour permettre au joueur d'avoir son score
    def __init__(self):
        super().__init__()
        
        # Configuration de l'interface utilisateur.
        self.ui = Ui_create()
        self.ui.setupUi(self)
        self.ui.Conteneur.setFocusPolicy(QtCore.Qt.StrongFocus) #Permet de bouger avec les flêches, on se concentre juste dans le conteneur
        
        #Ajout de l'arriere Plan
        palette = QtGui.QPalette()
        pixmap = QtGui.QPixmap("fond_menu2.png")
        palette.setBrush(QtGui.QPalette.Background,QtGui.QBrush(pixmap))
        self.setPalette(palette)
        
        #Initialisation du plateau et des variables utiles    
        self.genere_plateau()
        self.deja_joueur='non'
        self.ready='non'
        
        #Connexion entre les boutons et les méthodes
        self.ui.boutonCharger.clicked.connect(self.genere_plateau)
        self.ui.boutonPlay.clicked.connect(self.go)
        self.ui.boutonHaut.clicked.connect(self.Mouvements_haut)
        self.ui.boutonDroite.clicked.connect(self.Mouvements_droit)
        self.ui.boutonGauche.clicked.connect(self.Mouvements_gauche)
        self.ui.boutonBas.clicked.connect(self.Mouvements_bas)
        self.ui.boutonRecommencer.clicked.connect(self.recommencer)
        self.ui.boutonRetour.clicked.connect(self.retour)
        self.ui.boutonCaisse.clicked.connect(self.create_caisse)
        self.ui.boutonSol.clicked.connect(self.create_sol)
        self.ui.boutonJoueur.clicked.connect(self.create_joueur)
        self.ui.boutonCible.clicked.connect(self.create_cible)
        self.ui.boutonMur.clicked.connect(self.create_mur)
        
        #Variables pour le dessin du plateau
        self.ecopainter = QtGui.QPainter()
        self.ui.Conteneur.paintEvent = self.drawecosysteme
        
        #Création de la barre de Menu pour la MainWindow
        extractAction = QtGui.QAction("&Quitter le jeu", self)
        extractAction.setShortcut("Ctrl+C")
        extractAction.setStatusTip('Leave The App')
        extractAction.triggered.connect(self.close_application)
        self.statusBar()
        extractAction3 = QtGui.QAction("&Règles du jeu", self)
        extractAction3.setShortcut("Ctrl+R")
        extractAction3.setStatusTip('Règles du jeu')
        extractAction3.triggered.connect(self.affiche_regles)
        mainMenu = self.menuBar()
        fileMenu = mainMenu.addMenu('&Menu')
        fileMenu.addAction(extractAction)
        fileMenu.addAction(extractAction3)
        self.statusBar()
    
    
    
    def close_application(self):
        """
        Méthode permettant de fermer la fenêtre lorsque l'on utilise CTRL+C ou via 
        le Menu
        """
        sys.exit()



    def affiche_regles(self):
        """
        Methode permettant l'affichage des règles de l'édition. On peut l'obtenir via
        le Menu ou le raccourci CTRL+R. Les règles permettent au joueur de savoir ce
        qu'il peut ou ne peut pas faire. Pour les afficher, on va ouvir un Widget
        où les règles seront écrites dedans.
        """
        self.widget4 = QMainWindow(self)
        self.widget4.setCentralWidget(QWidget(self.widget4))
        self.widget4.setWindowTitle("Regle du Jeu")
        label=QLabel("""L'objectif est de vous amuser en créant vos propres niveaux de Sokoban.

Tout d'abord selectionnez une taille de grille sur votre droite puis appuyez sur Charger.
Ensuite, vous pouvez selectionner les éléments qui se situent sur la partie droite de l'interface et les inserer au plateau.
Pour cela, il suffit de cliquer sur un bouton puis quelque part sur le plateau, l'élément apparaitra aussitôt.
Attention, on ne peux mettre qu'un seul joueur par plateau!

Une fois votre plateau de jeu prêt, il vous suffit d'appuyer sur le bouton Play situé sur la gauche de votre écran.
Vous pourrez alors jouer tout simplement comme dans le mode histoire.

En effet, en haut à droite de votre écran vous pouvez observer le nombre de caisses restantes à trier ainsi que le nombre de pas que vous avez effectué jusqu'à présent.
Pour déplacer le joueur, soit pouvez utiliser les boutons directionnels ou bien les flèches directionnelles de votre clavier. Attention, si vous utilisez les flèches, il faudra appuyer avec 
le clic gauche de votre souris sur la fenetre de Jeu afin de dire au programme de se concentrer sur cette partie du Widget.

Le bouton Retour va vous permettre d'effectuer un retour en arrière (afin d'éviter les erreurs d'étourderie) mais attention, ce retour en arrière vous coutes un pas!
Le bouton recommencer vas ici recharger le plateau que vous avez construit! Pour un plateau vierge, il faut regarger la grille!

Amusez vous bien !""")
        mainLayout=QVBoxLayout(self.widget4.centralWidget()) #On affiche en forme de BOX
        mainLayout.addWidget(label)# On ajoute au Layout nos rêgles.
        self.widget4.show()
        
    def genere_plateau(self):
        """
        Cette méthode réalise la création du plateau de Jeu. Pour cela, on lit la 
        taille de la grille choisie par le joueur et on ouvre le fichier texte 
        correspondant. Ensuite on utilise les classe sPlateau_jeu et Joueur_case
        qui vont nous créer notre plateau de jeu (ici que du sol et des murs).
        Le plateau 2 va nous servir pour le retour.
        """
        niv=self.ui.Choix_niveau.currentText()#On récupère le choix du Joueur
        self.plateau=Joueur_case(Plateau_jeu('nivo'+str(niv)+'.txt')).plateau
        self.plateau2=Joueur_case(Plateau_jeu('nivo'+str(niv)+'.txt')).plateau2
        self.nbr_pas=0#On réinitialise le nombre de pas car on lance une grille vierge
        self.nbr_caisse=self.plateau.gagne()[2] #On récupère le nombre de caisse initial
        self.ui.lcd_pas.display(self.nbr_pas)#On affiche les nombres de pas et de caisse sur les écrans LCD en haut à droite
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.deja_joueur='non' #Il n'y a toujours pas de joueur sur le plateau
        self.ready='non'#Le bouton Play n'a pas été enclanché
        self.ui.centralwidget.update()
        

   
    def mousePressEvent(self,event):
        """
        Cette méthode va nous permettre d'utiliser notre souris pour placer les composants
        là où on le désire. En effet, une fois qu'on a choisi notre composant, et que
        le bouton Play n'est pas enclanché, on récupère les coordronées du click gauche de la 
        souris puis à l'aide d'un petit calcul, on retrouve la case du Plateau à modifier.
        """
        if self.choix_composant=='caisse' and self.ready!='ok':#On regarde le choix du composant et on vérifie que le bouton Play n'a pas été enfoncé auparavant
            if event.button() == Qt.LeftButton: #Dès lors qu'on clique avec le clique gauche:
                x=event.x()#On récupère les coordonnées x et y du click sur la fenêtre
                y=event.y()
                x_selct=int((x-100)/self.taille)#on calcul les coordonées du plateau correspondantes
                y_selct=int((y-140)/self.taille)
                self.plateau[y_selct,x_selct]='6'#on affetecte le choix du composant
                self.ui.centralwidget.update()#Et on actualise la fenêtre

        if self.choix_composant=='mur'and self.ready!='ok':
             if event.button() == Qt.LeftButton:
                x=event.x()
                y=event.y()
                x_selct=int((x-100)/self.taille)
                y_selct=int((y-140)/self.taille)
                self.plateau[y_selct,x_selct]='1'
                self.ui.centralwidget.update()
                
        if self.choix_composant=='sol'and self.ready!='ok':
             if event.button() == Qt.LeftButton:
                x=event.x()
                y=event.y()
                x_selct=int((x-100)/self.taille)
                y_selct=int((y-140)/self.taille)
                self.plateau[y_selct,x_selct]='4'
                self.ui.centralwidget.update()
        
        if self.choix_composant=='cible'and self.ready!='ok':
             if event.button() == Qt.LeftButton:
                x=event.x()
                y=event.y()
                x_selct=int((x-100)/self.taille)
                y_selct=int((y-140)/self.taille)
                self.plateau[y_selct,x_selct]='8'
                self.ui.centralwidget.update()
        
        
        if self.choix_composant=='joueur'and self.ready!='ok': #On ne peut pas avoir plus d'un joueur
            if event.button() == Qt.LeftButton:
                for a in range (self.plateau.shape[0]):
                    for b in range (self.plateau.shape[1]):
                        if self.plateau[a,b]=='5':
                            self.deja_joueur='ok'
                while self.deja_joueur=='non':            
                    x=event.x()
                    y=event.y()
                    x_selct=int((x-100)/self.taille)
                    y_selct=int((y-140)/self.taille)
                    self.plateau[y_selct,x_selct]='5'
                    self.deja_joueur='ok'
                    self.ui.centralwidget.update()

                    
    def go(self):
        """
        La méthode go va changer la variable ready à 'ok' afin de marquer le ddébut de la phase
        de jeu. Elle est relier au bouton Play. De plus, on fait une copie pour pouvoir recommencer
        le niveau créer (voir méthode recommencer).
        """
        self.ready='ok'
        self.memoire=self.plateau.copy()
        self.ui.centralwidget.update()
    
    
    def create_caisse(self):
        """
        Dans ces méthodes, qui sont toutes reliées à des boutons correspondant aux composants, 
        on modifie la variable choix_composant.
        """
        self.choix_composant='caisse'
        
    def create_mur(self):
        self.choix_composant='mur'
    
    def create_sol(self):
        self.choix_composant='sol'
    
    def create_cible(self):
        self.choix_composant='cible'
    
    def create_joueur(self):
        self.choix_composant='joueur'
        
    def Mouvements_haut(self):
        """
        Dans ces méthodes, on fait bouger notre plateau. On s'assure tout d'abord que le bouton
        Play a bien été enfoncé auparavant puis on va utiliser la méthode bouger_joueur_mouvement()
        de la classe Joueur_case(). On va donc actualiser notre plateau avec le bon mouvement.
        Ensuite on ajoute un au nombre de pas effectués qu'on actualise sur l'écran LCD.
        Enfin, on regarde si on a gagné, ie qu'il n'ya plus de caisses à ranger, avec la 
        méthode gagne(plateau). Si c'est le cas on affiche le message de Victoire à l'aide de la
        méthode Victoire()
        """
        if self.ready=='ok':
            j=Joueur_case(self.plateau)
            self.a=j.plateau2.copy()#Pour le retour en arrière
            j.bouger_joueur_haut() #On actualise le plateau de jeu
            self.nbr_pas+=1#on augmente le nombre de pas
            self.ui.lcd_pas.display(self.nbr_pas)
            self.nbr_caisse=self.gagne(self.plateau)[2]#on actualise le nombre de caisse
            self.ui.lcd_caisse.display(self.nbr_caisse)
            self.victoire(self.plateau)#S'il n'y plus de caisses à ranger alors on affiche le message de victoire
            self.ui.centralwidget.update()


    def Mouvements_droit(self):
        if self.ready=='ok':
            j=Joueur_case(self.plateau)
            self.a=j.plateau2.copy()#Pour le retour en arrière
            j.bouger_joueur_droit()
            self.nbr_pas+=1
            self.ui.lcd_pas.display(self.nbr_pas)
            self.nbr_caisse=self.gagne(self.plateau)[2]
            self.ui.lcd_caisse.display(self.nbr_caisse)
            self.victoire(self.plateau)
            self.ui.centralwidget.update()
    
    def Mouvements_bas(self):
        if self.ready=='ok':        
            j=Joueur_case(self.plateau)
            self.a=j.plateau2.copy()#Pour le retour en arrière
            j.bouger_joueur_bas()
            self.nbr_pas+=1
            self.ui.lcd_pas.display(self.nbr_pas)
            self.nbr_caisse=self.gagne(self.plateau)[2]
            self.ui.lcd_caisse.display(self.nbr_caisse)
            self.victoire(self.plateau)
            self.ui.centralwidget.update()
    
    def Mouvements_gauche(self):
        if self.ready=='ok':
            j=Joueur_case(self.plateau)
            self.a=j.plateau2.copy()#Pour le retour en arrière
            j.bouger_joueur_gauche()
            self.nbr_pas+=1
            self.ui.lcd_pas.display(self.nbr_pas)
            self.nbr_caisse=self.gagne(self.plateau)[2]
            self.ui.lcd_caisse.display(self.nbr_caisse)
            self.victoire(self.plateau)
            self.ui.centralwidget.update()
    
    def retour(self):
        """
        Cette méthode permet de réaliser un et un seul retour en arrière (pour éviter les erreurs 
        d'étourderies). La variable plateau va donc reprendre la forme qu'elle avait au coup d'avant
        que nous avons stocké dans la variable a.
        Bien sur cela coûte un pas donc n'en abusez pas!
        """
        self.plateau=self.a#On met la variable plateau comme elle était auparavant
        self.nbr_pas+=1#On augment de 1 le nombre de pas
        self.ui.lcd_pas.display(self.nbr_pas)
        self.nbr_caisse=self.gagne(self.a)[2]
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.ui.centralwidget.update()
        
    def gagne(self,plateau): 
        """
        Permet de stopper le niveau lorsque le joueur a déposer toutes les caisses sur les cibles.
        Cette fonction sert aussi à indiquer dans la console le nombre de caisse qu'il lui reste à ranger.
        """
        self.xm=self.plateau.shape[0]
        self.ym=self.plateau.shape[1]
        win= True
        caisse_a_ranger=0
        for i in range(self.xm):
            for j in range(self.ym):
                if self.plateau[i,j]==6:#self[i,j] est la case de coodronée i,j du plateau de jeu
                    win=False
                    caisse_a_ranger+=1
        return (win, "Il reste {0} caisses à ranger.".format(caisse_a_ranger),caisse_a_ranger)

    def recommencer(self):
        """
        Permet au joueur de recommencer le niveau qu'il a créer sans tout recommencer depuis le 
        début. On reprends la variable memoire que l'on a créé lorsque l'on a généré le plateau
        """
        self.plateau=self.memoire
        self.nbr_pas=0#On remet à zero le compteur de pas
        self.nbr_caisse=self.a.gagne()[2]
        self.ui.lcd_pas.display(self.nbr_pas)
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.ui.centralwidget.update()
        
    def victoire(self,plateau):
        """
        Permet d'afficher un message de type Widget lorsque le joueur a réussi à ranger toutes 
        les caisses sur les goals. Le message indiquera de plus le nombre de pas que le joueur
        a eu besoin pour finir le niveau.
        """
        if self.gagne(plateau)[0]==True:
            self.widget = QMainWindow(self)
            self.widget.setCentralWidget(QWidget(self.widget))
            self.widget.setWindowTitle("Victoire")
            label=QLabel("Felicitation, vous avez réussi le niveau  et ceci en "+str(self.nbr_pas)+" pas.\n Créez un autre niveau pour plus de Fun !")
            mainLayout=QVBoxLayout(self.widget.centralWidget())
            mainLayout.addWidget(label)
            self.widget.show()
            
    def keyPressEvent(self, event):
        """
        Cette méthode permet à l'utilisateur de pouvoir utiliser son clavier en complement des
        boutons directionnels sur l'écran. A chaque appui sur la touche correspondante, on 
        lance une méthode de déplacement
        """
        if event.key() == QtCore.Qt.Key_Up:
            self.Mouvements_haut()

        if event.key() == QtCore.Qt.Key_Left:
            self.Mouvements_gauche()

        if event.key() == QtCore.Qt.Key_Down:
            self.Mouvements_bas()

        if event.key() == QtCore.Qt.Key_Right:  
            self.Mouvements_droit()

        
    def drawecosysteme(self, *args):
        """
        Cette méthode nous permet de déssinner notre plateau de Jeu. Premièrement, on regarde 
        le choix fait par l'utilisateur et on adapte la taille de la grille en fonction du nombre 
        d'élément composant le plateau avec la variable taille.
        Ensuite, on charge les images correspondantes aux différents composants du jeu puis on 
        parcourt notre plateau en dessinnant, pour chaque composant, l'image qui lui est associée.
        Pour ce faire, on va venir dessinner un carré dont le sommet en haut à gauche est la 
        l'indice du composant dans le plateau modulo la variable taille.
        """
        if self.ui.Choix_niveau.currentText()=='10x10': #On regarde le choix du joueur
            self.taille=52
        elif self.ui.Choix_niveau.currentText()=='15x15':
            self.taille=35
        elif self.ui.Choix_niveau.currentText()=='20x20':
            self.taille=26
        self.ecopainter.begin(self.ui.Conteneur)#Outils pour le dessin
        self.ecopainter.setPen(QtCore.Qt.red)
        largeur=self.plateau.shape[0] #on récupère les dimensions du plateau
        hauteur=self.plateau.shape[1]
        image1 = QtGui.QImage("homme50x50.png")#On charge les images
        image2 = QtGui.QImage("sol50x50.png")
        image3 = QtGui.QImage("mur50x50.png")
        image4 = QtGui.QImage("goal50x50.png")
        image5 = QtGui.QImage("caisse50x50.png")
        image6 = QtGui.QImage("caisseok50x50.png")
        haut,larg=140,100#on se décale un peu du bords pour plus de visibilité
        for x in range (largeur):
            for y in range(hauteur): #Enfin, on dessinne !
                if self.plateau[x,y] == 5:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille,self.taille),image1)
                elif self.plateau[x,y] == 4:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image2)
                elif self.plateau[x,y] == 1:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image3)
                elif self.plateau[x,y] == 8:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image4)
                elif self.plateau[x,y] == 6:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image5)
                elif self.plateau[x,y] == 0:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image6)
                elif self.plateau[x,y] == 9:
                    self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image1)
                
                larg=larg+self.taille
            haut=haut+self.taille
            larg=100
        self.ecopainter.end()#On stop le processus de dessin jusqu'à la prochaine action
        
        
        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Creat()
    window.show()
    app.exec_()