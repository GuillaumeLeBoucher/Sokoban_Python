# -*- coding: utf-8 -*-
"""
Created on Sat May 12 21:52:24 2018

@author: guillaume
"""

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys

from Plateau_Jeu import *
from Menu import *
from Joueur import *
import ihm_rc

"""
La classe Menu(), qui hérite de la classe Ui_Menu fournie par Qt Designer, permet de
réaliser un menu principal où le joueur aura à choisir entre le mode histoire où il 
pourra jouer à des niveaux déjà conçus et le mode édition où il pourra créer son 
propre plateau de jeu et jouer à ses propres niveaux.

Le principe est d'utiliser 2 boutons push pour lancer soit la fenêtre de jeu, soit la 
fênetre d'édition. Ici, lorsque le joueur va appuyer sur un bouton, la variable choix
va prendre la valeur 'Jeu' ou 'Creat' puis fermer le menu (les boutons sont reliés
à quit() via QtDesigner. Dans le main, on regardera la valeur de cette 
variable et on ouvrira les fenêtres correspondantes en fonction de celui-ci.
"""
class Menu(QMainWindow,Ui_Menu):
    def __init__(self):
        super().__init__()
        # Configuration de l'interface utilisateur.

        self.ui = Ui_Menu()
        self.ui.setupUi(self)
        self.choix=None

        
#       Ajout de l'arriere Plan
        palette = QtGui.QPalette()
        pixmap = QtGui.QPixmap("fond_menu2.png")
        palette.setBrush(QtGui.QPalette.Background,QtGui.QBrush(pixmap))
        self.setPalette(palette)
        
        #Connexion entre les boutons et les méthodes
        self.ui.boutonGO1.clicked.connect(self.Go_jeu)
        self.ui.boutonGO2.clicked.connect(self.Go_creat)
        
         
    def Go_jeu(self):
        self.choix='Jeu' #On choisi ici de Jouer
        self.ui.centralwidget.update()
        
    def Go_creat(self):
        self.choix='Creat'#On choisi ici d'Éditer
        self.ui.centralwidget.update()


        
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Menu()
    window.show()
    app.exec_()
