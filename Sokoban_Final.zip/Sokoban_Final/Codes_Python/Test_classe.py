# -*- coding: utf-8 -*-
"""
Created on Tue May  8 22:33:19 2018

@author: SYSTEM
"""
import numpy as np 
import unittest
from Plateau_Jeu import Plateau_jeu
from Aide_joueur import Case,Aide_Joueur
from Joueur import Joueur_case

class Test_general(unittest.TestCase):
    def test_plateau(self):
        plateau=Plateau_jeu("nivo1.txt")
        self.assertIsNot(plateau.xm,plateau.ym)
        self.assertIsInstance(plateau,np.ndarray)
        
        
        
    def test_joueur(self):
        
        plateau=Plateau_jeu("nivo1.txt")
        j=Joueur_case(plateau)
        self.assertEqual(j.x,j.coords[0])
        self.assertEqual(j.y,j.coords[1])
        
        
    def test_Aide_joueur(self):
        plateau=Plateau_jeu("nivo1.txt")
        Aide=Aide_Joueur(plateau)
        self.assertIsInstance(Aide.cases,list)
        self.assertIsInstance(Aide.case_dispo,list)
        self.assertEqual(Aide.hauteur_plateau,plateau.xm)
        self.assertEqual(Aide.largeur_plateau,plateau.ym)
        
        
        
    def test_case(self):
        A=Case(5,5,True)
        self.assertEqual(A.x,5)
        self.assertEqual(A.y,5)
        self.assertIsInstance(A.accessible,bool)
        self.assertEqual(A.g,0)
        self.assertEqual(A.h,0)
        self.assertEqual(A.f,0)

if __name__ == '__main__':
    unittest.main()