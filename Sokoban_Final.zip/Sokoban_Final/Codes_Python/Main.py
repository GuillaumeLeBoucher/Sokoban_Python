# -*- coding: utf-8 -*-
"""
Created on Fri May 18 01:08:14 2018

@author: guillaume
"""

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys

from Menu_principal import *
from ModeHistoire import *
from creat_niv import *

"""
On est ici sur le main du programme, lorsqu'on va venir lancer celui-ci, on va commencer par
afficher la fenêtre du menu principal. Ensuite, le joueur va venir choisir soit de joueur, soit
de créer des niveaux. Suivant son choix on ouvre la ffenêtre correspondante.
"""
if __name__ == "__main__":
    app = QApplication(sys.argv)
    window = Menu()
    window.show()
    app.exec_()
    if window.choix=='Jeu':
        jeu = Jeu()
        jeu.show()
        app.exec_()
    if window.choix=='Creat':
        creat=Creat()
        creat.show()
        app.exec_()
#        Fich_nouv_niveau.write()
#        Fich_nouv_niveau.close()
