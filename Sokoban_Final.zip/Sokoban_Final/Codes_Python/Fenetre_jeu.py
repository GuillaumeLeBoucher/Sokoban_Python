# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'Fenetre_jeu.ui'
#
# Created by: PyQt4 UI code generator 4.11.4
#
# WARNING! All changes made in this file will be lost!

from PyQt4 import QtCore, QtGui

try:
    _fromUtf8 = QtCore.QString.fromUtf8
except AttributeError:
    def _fromUtf8(s):
        return s

try:
    _encoding = QtGui.QApplication.UnicodeUTF8
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig, _encoding)
except AttributeError:
    def _translate(context, text, disambig):
        return QtGui.QApplication.translate(context, text, disambig)

class Ui_Fenetre_jeu(object):
    def setupUi(self, Fenetre_jeu):
        Fenetre_jeu.setObjectName(_fromUtf8("Fenetre_jeu"))
        Fenetre_jeu.resize(1480, 794)
        self.centralwidget = QtGui.QWidget(Fenetre_jeu)
        self.centralwidget.setObjectName(_fromUtf8("centralwidget"))
        self.Conteneur = QtGui.QWidget(self.centralwidget)
        self.Conteneur.setGeometry(QtCore.QRect(-30, 20, 1341, 711))
        self.Conteneur.setObjectName(_fromUtf8("Conteneur"))
        self.label = QtGui.QLabel(self.Conteneur)
        self.label.setGeometry(QtCore.QRect(950, 150, 191, 61))
        self.label.setObjectName(_fromUtf8("label"))
        self.Choix_Niveau = QtGui.QSpinBox(self.Conteneur)
        self.Choix_Niveau.setGeometry(QtCore.QRect(1130, 156, 71, 41))
        self.Choix_Niveau.setLayoutDirection(QtCore.Qt.LeftToRight)
        self.Choix_Niveau.setWrapping(False)
        self.Choix_Niveau.setMaximum(4)
        self.Choix_Niveau.setObjectName(_fromUtf8("Choix_Niveau"))
        self.boutonRetour = QtGui.QPushButton(self.Conteneur)
        self.boutonRetour.setGeometry(QtCore.QRect(990, 220, 111, 31))
        self.boutonRetour.setObjectName(_fromUtf8("boutonRetour"))
        self.boutonRecommencer = QtGui.QPushButton(self.Conteneur)
        self.boutonRecommencer.setGeometry(QtCore.QRect(990, 290, 111, 31))
        self.boutonRecommencer.setObjectName(_fromUtf8("boutonRecommencer"))
        self.boutonAide = QtGui.QPushButton(self.Conteneur)
        self.boutonAide.setGeometry(QtCore.QRect(990, 360, 111, 31))
        self.boutonAide.setObjectName(_fromUtf8("boutonAide"))
        self.credits = QtGui.QLabel(self.Conteneur)
        self.credits.setGeometry(QtCore.QRect(180, 680, 771, 17))
        self.credits.setObjectName(_fromUtf8("credits"))
        self.boutonPlay = QtGui.QPushButton(self.Conteneur)
        self.boutonPlay.setGeometry(QtCore.QRect(1220, 160, 99, 27))
        self.boutonPlay.setObjectName(_fromUtf8("boutonPlay"))
        self.boutonHaut = QtGui.QPushButton(self.Conteneur)
        self.boutonHaut.setGeometry(QtCore.QRect(1140, 450, 99, 27))
        self.boutonHaut.setObjectName(_fromUtf8("boutonHaut"))
        self.boutonGauche = QtGui.QPushButton(self.Conteneur)
        self.boutonGauche.setGeometry(QtCore.QRect(1050, 490, 99, 27))
        self.boutonGauche.setObjectName(_fromUtf8("boutonGauche"))
        self.boutonBas = QtGui.QPushButton(self.Conteneur)
        self.boutonBas.setGeometry(QtCore.QRect(1140, 530, 99, 27))
        self.boutonBas.setObjectName(_fromUtf8("boutonBas"))
        self.boutonDroite = QtGui.QPushButton(self.Conteneur)
        self.boutonDroite.setGeometry(QtCore.QRect(1230, 490, 99, 27))
        self.boutonDroite.setObjectName(_fromUtf8("boutonDroite"))
        self.lcd_pas = QtGui.QLCDNumber(self.Conteneur)
        self.lcd_pas.setGeometry(QtCore.QRect(1240, 10, 64, 23))
        self.lcd_pas.setObjectName(_fromUtf8("lcd_pas"))
        self.lcd_caisse = QtGui.QLCDNumber(self.Conteneur)
        self.lcd_caisse.setGeometry(QtCore.QRect(1240, 70, 64, 23))
        self.lcd_caisse.setObjectName(_fromUtf8("lcd_caisse"))
        self.label_2 = QtGui.QLabel(self.Conteneur)
        self.label_2.setGeometry(QtCore.QRect(1030, -10, 201, 61))
        self.label_2.setObjectName(_fromUtf8("label_2"))
        self.label_3 = QtGui.QLabel(self.Conteneur)
        self.label_3.setGeometry(QtCore.QRect(1000, 50, 231, 61))
        self.label_3.setObjectName(_fromUtf8("label_3"))
        Fenetre_jeu.setCentralWidget(self.centralwidget)
        self.menubar = QtGui.QMenuBar(Fenetre_jeu)
        self.menubar.setGeometry(QtCore.QRect(0, 0, 1480, 25))
        self.menubar.setObjectName(_fromUtf8("menubar"))
        Fenetre_jeu.setMenuBar(self.menubar)
        self.statusbar = QtGui.QStatusBar(Fenetre_jeu)
        self.statusbar.setObjectName(_fromUtf8("statusbar"))
        Fenetre_jeu.setStatusBar(self.statusbar)
        self.actionRetour_au_menu_principal = QtGui.QAction(Fenetre_jeu)
        self.actionRetour_au_menu_principal.setObjectName(_fromUtf8("actionRetour_au_menu_principal"))
        self.actionQuitter_le_jeu = QtGui.QAction(Fenetre_jeu)
        self.actionQuitter_le_jeu.setObjectName(_fromUtf8("actionQuitter_le_jeu"))

        self.retranslateUi(Fenetre_jeu)
        QtCore.QObject.connect(self.actionQuitter_le_jeu, QtCore.SIGNAL(_fromUtf8("activated()")), Fenetre_jeu.close)
        QtCore.QObject.connect(self.actionRetour_au_menu_principal, QtCore.SIGNAL(_fromUtf8("changed()")), Fenetre_jeu.close)
        QtCore.QMetaObject.connectSlotsByName(Fenetre_jeu)

    def retranslateUi(self, Fenetre_jeu):
        Fenetre_jeu.setWindowTitle(_translate("Fenetre_jeu", "Jeu_Sokoban", None))
        self.label.setText(_translate("Fenetre_jeu", "<html><head/><body><p><span style=\" font-size:16pt; font-weight:600; color:#ffff7f;\">Choix du niveau :</span></p></body></html>", None))
        self.boutonRetour.setText(_translate("Fenetre_jeu", "Retour", None))
        self.boutonRecommencer.setText(_translate("Fenetre_jeu", "Recommencer", None))
        self.boutonAide.setText(_translate("Fenetre_jeu", "Aide", None))
        self.credits.setText(_translate("Fenetre_jeu", "<html><head/><body><p><span style=\" color:#838383;\">Jeu créé par Maël Bourhis et Guillaume Le Boucher dans le cadre d\'un projet informatique à l\'ENSTA Bretagne.</span></p></body></html>", None))
        self.boutonPlay.setText(_translate("Fenetre_jeu", "Play", None))
        self.boutonHaut.setText(_translate("Fenetre_jeu", "HAUT", None))
        self.boutonGauche.setText(_translate("Fenetre_jeu", "GAUCHE", None))
        self.boutonBas.setText(_translate("Fenetre_jeu", "BAS", None))
        self.boutonDroite.setText(_translate("Fenetre_jeu", "DROITE", None))
        self.label_2.setText(_translate("Fenetre_jeu", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#aaaaff;\">Nombre de pas effectués :</span></p></body></html>", None))
        self.label_3.setText(_translate("Fenetre_jeu", "<html><head/><body><p><span style=\" font-size:12pt; font-weight:600; color:#aaaaff;\">Nombre de caisses restantes :</span></p></body></html>", None))
        self.actionRetour_au_menu_principal.setText(_translate("Fenetre_jeu", "Retour au menu principal", None))
        self.actionQuitter_le_jeu.setText(_translate("Fenetre_jeu", "Quitter le jeu", None))
        self.actionQuitter_le_jeu.setShortcut(_translate("Fenetre_jeu", "Ctrl+C", None))

