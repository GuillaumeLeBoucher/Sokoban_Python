# -*- coding: utf-8 -*-
"""
Created on Wed May  9 19:22:28 2018

@author: guillaume
"""
from Joueur import *
import numpy as np
from Plateau_Jeu import *


"""
Ce code reprends les concepts de l'algorithme A* (expliqué dans le rapport).
On le divise en deux classes, une classe case qui va comprendre toutes les cractéristiques de 
nos différentes cases du jeu et une classe Aide_Joueur qui va determiner le plus court chemin
entre le joueur et une caisse.
"""
class Case(object):
    def __init__(self, x, y, accessible): #les variables x et y correspondent à l'emplacement de la case, la variable accessible nous donne l'information concernant l'accessibilité de la case (mur, caisse...)
        self.accessible = accessible 
        self.x = x
        self.y = y
        self.parent = None
        self.g = 0
        self.h = 0
        self.f = 0
        
    def __str__(self): #Pour afficher les caractéristiques de la case sous une belle forme
        return 'Pos=({0},{1}), accessible? {5}, {2}, {3}, {4}'.format(self.x,self.y,self.g,self.h,self.f, self.accessible)


class Aide_Joueur(object): #Algorithme A_etoile pour chercher le plus court chemin entre le joueur et une caisse
    "Le principe de l'algorithme est décrit dans le rapport"
    def __init__(self,plateau):#On prends en paramètre un plateau de jeu classique
        self.plateau=plateau        
        self.case_dispo = []#Liste des cases disponibles
        self.case_deja_faites = set() #Crée un ensemble: une collection (dictionnaire) non ordonée et sans éléments dupliqués
        self.cases = []#liste de toutes les cases en utilisant la forme de la classe case
        self.caisses_coord = []#liste des coodonnées des caisses
        self.trou_coord=[]#liste des coodonnées des trous
        self.hauteur_plateau= plateau.shape[0]
        self.largeur_plateau = plateau.shape[1] 
        for x in range(self.hauteur_plateau):
            for y in range(self.largeur_plateau):#On parcourt le plateau de jeu
                if self.plateau[x][y]==6: #Si on tombe sur une caisse 
                    self.caisses_coord.append([x,y])#On rentre ses coordonnées
                if self.plateau[x][y]==8: #On stocke les coordonées des trous dans une liste
                    self.trou_coord.append([x,y])
                if self.plateau[x][y]==1 or self.plateau[x][y]==8: #On met à false les murs ou des caisses et à true les cases vides
                    accessible = False
                else:
                    accessible = True
                self.cases.append(Case(x, y, accessible))
        self.start = self.pointeur_case(Joueur_case(plateau).coords[0],Joueur_case(plateau).coords[1]) #Coordonnées du joueur
        #Sur toutes les caisses que l'on a repéré on commence par la plus proche
        l=[]
        for i in self.caisses_coord:
            l.append([abs(i[0] - self.start.x) + abs(i[1] - self.start.y),i]) #On calcul la distance en vol d'oiseau du joueur a chaque caisses
        a=l[0][0]
        b=l[0][1]
        for j in range(0,len(l)):
            if l[j][0]<a:
                a=l[j][0]
                b=l[j][1]
        self.start = self.pointeur_case(Joueur_case(self.plateau).coords[0],Joueur_case(self.plateau).coords[1])
        self.end = self.pointeur_case(b[0],b[1]) #Coodronnée de la case la plus proche 
    
    def __str__(self): #Affichage des infos de chaque case 
        s='{'
        for i, case in enumerate(self.cases):        
            if i%(self.largeur_plateau)==0:
                s+=','
            if i>0:
                s+='\n'
            s+='[{}]'.format(case)
        s+='}'
        return s
            
        
    def distance_target(self, case): #Permet d'avoir la valeur du H (à vol d'oiseau) multipliée par 10
        return (abs(case.x - self.end.x) + abs(case.y - self.end.y))
        
    def pointeur_case(self, x, y):#Sert à recupérer une cellule de coordonée (x,y) dans la liste
        return self.cases[x * self.largeur_plateau + y]
        
        
    def cases_voisines(self, case): #récupère les cases adjacentes et leurs renseignements
        cases = []
        if case.x < self.largeur_plateau-1:
            cases.append(self.pointeur_case(case.x+1, case.y))
        if case.y > 0:
            cases.append(self.pointeur_case(case.x, case.y-1))
        if case.x > 0:
            cases.append(self.pointeur_case(case.x-1, case.y))
        if case.y < self.hauteur_plateau-1:
            cases.append(self.pointeur_case(case.x, case.y+1))
        return cases

    def chemin(self):#Affiche le chemin que l'on a trouvé pour resoudre le probleme
        self.L=[]	    
        case = self.end
        while case.parent is not self.start:
               case = case.parent
               self.L.append((case.x, case.y))
               print ('path: case: %d,%d' % (case.x, case.y))

    def maj_case(self, vois, case): #Met à jour la case sur laquelle on se trouve
	    vois.g = case.g + 1
	    vois.h = self.distance_target(vois)
	    vois.parent = case
	    vois.f = vois.h + vois.g  
     
     
    def process(self):
        self.case_dispo=[(self.start.f, self.start)] #initialisation des cases accessibles
        while len(self.case_dispo)>0: #Tant qu'il reste des cases vides à explorer      
            f, case = self.case_dispo.pop(0)#On recupère le "coût" de la case (f=coût) et la case elle même (la première)
            self.case_deja_faites.add(case) #on l'ajoute aux cases par lesquels nous sommes passé
            print(f,case.__str__())
            print(case.parent)
            if case is self.end:#Si on se siture sur la case de fin, on arête directement le programme
                self.chemin()
                break
            # on recupère les cases voisines
            cases_vois = self.cases_voisines(case)
            i=0
            for cases_vois in cases_vois: #Pour tous les voisins, on regarde si c'est bien des cases sol et si on est pas deja passé par la
                if cases_vois.accessible and cases_vois not in self.case_deja_faites:
                    if (cases_vois.f, cases_vois) in self.case_dispo:
                     
                        if cases_vois.g > case.g + 1:
                            self.maj_case(cases_vois, case)
                    else:
                        self.maj_case(cases_vois, case)
                        self.case_dispo.append((cases_vois.f, cases_vois))
                i+=1

      
    def fin_partie(self):# Méthode pour controler si les caisses ne sont pas dans les coins et nous avertir si c'est le cas.
        self.game_over=False
        for i in self.caisses_coord:
            if self.plateau[i[0]-1,i[1]]==1 or self.plateau[i[0]+1,i[1]]==1:
                if self.plateau[i[0],i[1]+1]==1 or self.plateau[i[0],i[1]-1]==1:
                   self.game_over=True
                   print("GAME OVER : Impossible de finir le Jeu ",i,"Caisse bloquée")
            
         
class caisse_proche_joueur(Aide_Joueur):# Cette méthode calcul la caisse la plus proche en distance oiseau : à modifier
        
    def action(self):
        l=[]
        for i in self.caisses_coord:
            l.append([abs(i[0] - self.start.x) + abs(i[1] - self.start.y),i]) #On calcul la distance en vol d'oiseau du joueur a chaque caisses
        a=l[0][0]
        b=l[0][1]
        for j in range(0,len(l)):
            if l[j][0]<a:
                a=l[j][0]
                b=l[j][1]                

        self.start = self.pointeur_case(Joueur_case(self.plateau).coords[0],Joueur_case(self.plateau).coords[1])
        self.end = self.pointeur_case(b[0],b[1]) 
        print("Chemin le plus court pour aller du joueur a la caisse :")
        
    
     
class caisse_proche_trou(Aide_Joueur):# Cette méthode calcul le trou le plus proche en distance oiseau du joueur
    def action(self):
            
        m=[]
        for i in self.trou_coord:
            m.append([abs(i[0] - self.start.x) + abs(i[1] - self.start.y),i]) #On calcul la distance en vol d'oiseau du joueur a chaque caisses
        a=m[0][0]
        b=m[0][1]
        for j in range(0,len(m)-1):
            if m[j][0]<a:
                a=m[j][0]
                b=m[j][1] 

        self.start = self.pointeur_case(b[0],b[1]) 
        self.end = self.pointeur_case(Joueur_case(self.plateau).coords[0],Joueur_case(self.plateau).coords[1])
        print("Chemin le plus court pour aller du joueur a un trou : ")

    
     

            
"Exemple"   
#A=Plateau_jeu('nivo1.txt')
#B=Aide_Joueur(A)
#B.process()
#print(B.L)    
   
