# -*- coding: utf-8 -*-
"""
Created on Sun May 13 00:09:46 2018

@author: guillaume
"""

from PyQt4.QtGui import *
from PyQt4.QtCore import *
import sys

from Plateau_Jeu import *
from Fenetre_jeu import *
from Joueur import *
from Menu_principal import *
from Aide_joueur import *

"""
La Classe Jeu(),qui hérite de la classe Ui_Fenetre_jeu fournie par Qt Designer, est la
classe qui va nous permettre de jouer à des niveaux déjà créés. Le joueur va venir choisir un
numéro de niveau allant de 0 à 4. Le niveau 0 est très simple tandis que le 5 est très compliqué.
Pour charger le niveau, il faut utiliser le bouton Play.

Une fois le niveau charger, on va pouvoir y jouer grâce aux bouton directionnels situés sur la
fenêtre de jeu mais aussi grâce au clavier et aux flêches directionnelles. Ces opérations vont
venir appeller des méthodes qui vont faire bouger le plateau et donc déplacer le joueur.

Les différents boutons vont permettre de simplifier la vie du Joueur dont le but est de finir 
le niveau avec le moins de déplacement possible. Le bouton Aide par exemple va montrer au 
joueur le plus plus court chemin entre lui et la caisse la plus proche. Le bouton retour va 
allouer au joueur un retour en arrière mais attention ceci coûte un deplacement.

Une fois toutes les caisses ranger, le jeu enregistre la performance du Joueur et affiche un 
message l'appelant à relancer une partie. Le joueur peut retrouver ses records de session dans 
la barre de Menu. 
"""

class Jeu(QMainWindow,Ui_Fenetre_jeu):
    nbr_pas=0#Compteur de pas pour permettre au joueur d'avoir son score
    def __init__(self):
        super().__init__()
        
        # Configuration de l'interface utilisateur.
        self.ui = Ui_Fenetre_jeu()
        self.ui.setupUi(self)
        self.ui.Conteneur.setFocusPolicy(QtCore.Qt.StrongFocus) #Permet de bouger avec les flêches, on se concentre juste dans le conteneur

        
#       Ajout de l'arriere Plan
        palette = QtGui.QPalette()
        pixmap = QtGui.QPixmap("fond_menu2.png")
        palette.setBrush(QtGui.QPalette.Background,QtGui.QBrush(pixmap))
        self.setPalette(palette)
        
        #Initialisation du plateau et des variables utiles pour le dessin 
        self.genere_plateau()
        self.ui.Conteneur.paintEvent = self.drawecosysteme
        self.ui.boutonPlay.clicked.connect(self.genere_plateau)
        self.ecopainter = QtGui.QPainter()
        
        #Connexion entre les boutons et les méthodes 
        self.ui.boutonPlay.clicked.connect(self.genere_plateau)
        self.ui.boutonHaut.clicked.connect(self.Mouvements_haut)
        self.ui.boutonDroite.clicked.connect(self.Mouvements_droit)
        self.ui.boutonGauche.clicked.connect(self.Mouvements_gauche)
        self.ui.boutonBas.clicked.connect(self.Mouvements_bas)
        self.ui.boutonRecommencer.clicked.connect(self.genere_plateau)
        self.ui.boutonRetour.clicked.connect(self.retour)
        self.ui.boutonAide.clicked.connect(self.Aide_joueur)

        #Création de la barre de Menu pour la MainWindow
        extractAction = QtGui.QAction("&Quitter le jeu", self)#Action pour quitter le jeu
        extractAction.setShortcut("Ctrl+C")#Raccourci
        extractAction.setStatusTip('Leave The App')
        extractAction.triggered.connect(self.close_application)
        extractAction2 = QtGui.QAction("&Afficher les records de la session en cours", self) #Action pour afficher les records
        extractAction2.setShortcut("Ctrl+Z")
        extractAction2.setStatusTip('Afficher les records de la session en cours')
        extractAction2.triggered.connect(self.scores)
        #On vient initialiser les différents records pour les diférents niveaux
        self.Records0=[QTextEdit("Niveau 0 : Vous n'avez pas encore réussi le niveau\n."),0] 
        self.Records1=[QTextEdit("Niveau 1 : Vous n'avez pas encore réussi le niveau\n."),0]  
        self.Records2=[QTextEdit("Niveau 2 : Vous n'avez pas encore réussi le niveau\n."),0]  
        self.Records3=[QTextEdit("Niveau 3 : Vous n'avez pas encore réussi le niveau\n."),0] 
        self.Records4=[QTextEdit("Niveau 4 : Vous n'avez pas encore réussi le niveau\n."),0] 
        self.statusBar()
        extractAction3 = QtGui.QAction("&Règles du jeu", self)#Action pour les règles du jeu
        extractAction3.setShortcut("Ctrl+R")
        extractAction3.setStatusTip('Règles du jeu')
        extractAction3.triggered.connect(self.affiche_regles)
        mainMenu = self.menuBar()
        fileMenu = mainMenu.addMenu('&Menu')
        fileMenu.addAction(extractAction)
        fileMenu.addAction(extractAction2)
        fileMenu.addAction(extractAction3)
        self.statusBar()
    
    def close_application(self):
        """
        Méthode permettant de fermer la fenêtre lorsque l'on utilise CTRL+C ou via 
        le Menu
        """        
        sys.exit()
        
    def affiche_regles(self):
        """
        Methode permettant l'affichage des règles de l'édition. On peut l'obtenir via
        le Menu ou le raccourci CTRL+R. Les règles permettent au joueur de savoir ce
        qu'il peut ou ne peut pas faire. Pour les afficher, on va ouvir un Widget
        où les règles seront écrites dedans.
        """
        self.widget4 = QMainWindow(self)
        self.widget4.setCentralWidget(QWidget(self.widget4))
        self.widget4.setWindowTitle("Regle du Jeu")
        label=QLabel("""L'objectif est d'enmener les caisses sur les goals (petits points rouges sur le sol) en bougeant le bonhome.

Tout d'abord selectionnez un niveau sur votre droite (il est recommandé de commencer avec le niveau 0 pour se familiariser avec les touches) puis appuyez sur Play.
En haut à droite de votre écran vous pouvez observer le nombre de caisses restantes à trier ainsi que le nombre de pas que vous avez effectué jusqu'à présent.
Pour déplacer le joueur, soit pouvez utiliser les boutons directionnels ou bien les flèches directionnelles de votre clavier. Attention, si vous utilisez les flèches, il faudra appuyer avec 
le clic gauche de votre souris sur la fenetre de Jeu afin de dire au programme de se concentrer sur cette partie du Widget.

Le bouton Retour va vous permettre d'effectuer un retour en arrière (afin d'éviter les erreurs d'étourderie) mais attention, ce retour en arrière vous coutes un pas!
Le bouton recommencer vas recharger le plateau dans son état initial.
Le bouton Aide va vous montrer un des plus court chemin entre le Joueur et la caisse la plus proche, il vous sera utile pour réaliser les meilleurs scores! Attention il faut aussi cliquer sur la 
fenetre de jeu pour dévoiler le chemin.

Marcher en direction d'un mur vous coutera un pas aussi.
Enfin, il y a dans le menu les scores que vous avez effectués durant cette session de jeu et ce sur tous les niveaux! 

Amusez vous bien !""")
        mainLayout=QVBoxLayout(self.widget4.centralWidget())
        mainLayout.addWidget(label)
        self.widget4.show()
        
    
    def scores(self):
        """
        Cette métode permet d'afficher les scores du Joueur sur les différents niveaux.Attention,
        il ne sont pas enregistrer éternellement mais juste pour la session en cours. L'idée est 
        de regarder le choix du niveau fait par le joueur puis dès que le niveau est terminer,
        on vient écrire dans un QTextEdit le nombre de pas que lui a nécessité la réalisation du
        niveau. L'intérêt d'un QTextEdit par rapport à un QLabel est qu'on peut comparer la valeur
        du nombre de pas à celle réalisée précedemment et ainsi permettre au joueur d'améliorer son
        record.
        """
        self.widget2 = QMainWindow(self)
        self.widget2.setCentralWidget(QWidget(self.widget2))
        self.widget2.setWindowTitle("Scores")
        mainLayout=QVBoxLayout(self.widget2.centralWidget())
        if self.ui.Choix_Niveau.value()==0:#On regarde le niveau choisi par le joueur 
            if self.gagne(self.plateau)[0]==True:#Dès lors que le joueur à gagné :
                if self.Records0[1]==0:#Si c'est la première fois qu'il gagne alors on modifie directement le QTextEdit
                    self.Records0[0]=QTextEdit("Niveau 0 : "+str(self.nbr_pas)+" pas.")
                    self.Records0[1]=1
                    self.rec=self.nbr_pas
                else:#Si ce n'est pas la première fois qu'il finit le niveau, on regarde si il a amélioré son score
                    if self.nbr_pas < self.rec: #Si on a amélioré le reccord, on  actualise le QTextEdit
                        self.Records0[0]=QTextEdit("Niveau 0 : "+str(self.nbr_pas)+" pas.")
                        self.rec=self.nbr_pas
                        
        elif self.ui.Choix_Niveau.value()==1:
            if self.gagne(self.plateau)[0]==True:
                if self.Records1[1]==0:
                    self.Records1[0]=QTextEdit("Niveau 1 : "+str(self.nbr_pas)+" pas.")
                    self.Records1[1]=1
                    self.rec1=self.nbr_pas
                else:
                    if self.nbr_pas < self.rec1: #Si on a amélioré le reccord, on  actualise le QTextEdit
                        self.Records1[0]=QTextEdit("Niveau 1 : "+str(self.nbr_pas)+" pas.")#toPlainText permet de modifier le texte
                        self.rec1=self.nbr_pas
                        
        elif self.ui.Choix_Niveau.value()==2:
            if self.gagne(self.plateau)[0]==True:
                if self.Records2[1]==0:
                    self.Records2[0]=QTextEdit("Niveau 2 : "+str(self.nbr_pas)+" pas.")
                    self.Records2[1]=1
                    self.rec2=self.nbr_pas
                else:
                    if self.nbr_pas < self.rec2: #Si on a amélioré le reccord, on  actualise le QTextEdit
                        self.Records2[0]=QTextEdit("Niveau 2 : "+str(self.nbr_pas)+" pas.")#toPlainText permet de modifier le texte
                        self.rec2=self.nbr_pas
                        
        elif self.ui.Choix_Niveau.value()==3:
            if self.gagne(self.plateau)[0]==True:
                if self.Records3[1]==0:
                    self.Records3[0]=QTextEdit("Niveau 3 : "+str(self.nbr_pas)+" pas.")
                    self.Records3[1]=1
                    self.rec3=self.nbr_pas
                else:
                    if self.nbr_pas < self.rec3: #Si on a amélioré le reccord, on  actualise le QTextEdit
                        self.Records3[0]=QTextEdit("Niveau 3 : "+str(self.nbr_pas)+" pas.")#toPlainText permet de modifier le texte
                        self.rec3=self.nbr_pas
                        
        elif self.ui.Choix_Niveau.value()==4:
            if self.gagne(self.plateau)[0]==True:
                if self.Records4[1]==0:
                    self.Records4[0]=QTextEdit("Niveau 4 : "+str(self.nbr_pas)+" pas.")
                    self.Records4[1]=1
                    self.rec1=self.nbr_pas
                else:
                    if self.nbr_pas < self.rec4: #Si on a amélioré le reccord, on  actualise le QTextEdit
                        self.Records4[0]=QTextEdit("Niveau 4 : "+str(self.nbr_pas)+" pas.")#toPlainText permet de modifier le texte
                        self.rec4=self.nbr_pas
                        
        mainLayout.addWidget(self.Records0[0])
        mainLayout.addWidget(self.Records1[0])
        mainLayout.addWidget(self.Records2[0])
        mainLayout.addWidget(self.Records3[0])
        mainLayout.addWidget(self.Records4[0])
        self.widget2.show()
        
    def bloquage_caisse(self,plateau):
        """
        Cette classe permet de prévenir le joueur lorsqu'il a coincé une caisse dans un coin. Il est
        impossible de ranger une caisse qui est dans un coin, on prévient donc le joueur à l'aide d'une fenetre qu'il
        doit recommencer ou bien faire un retour. Pour cela on utilis la méthode fin_partie de
        la classe Aide_Joueur(plateau).
        """
        A=Aide_Joueur(plateau)
        A.fin_partie()
        if A.game_over==True:
            self.widget3 = QMainWindow(self)
            self.widget3.setCentralWidget(QWidget(self.widget3))
            self.widget3.setWindowTitle("Perdu")
            label=QLabel("GAME OVER : Impossible de finir le Jeu il y a une caisse de bloquée.\n Fait un retour, recommence le niveau ou passe le !")
            mainLayout=QVBoxLayout(self.widget3.centralWidget())
            mainLayout.addWidget(label)
            self.widget3.show()
        
    def victoire(self,plateau):
        """
        Permet d'afficher un message de type Widget lorsque le joueur a réussi à ranger toutes 
        les caisses sur les goals. Le message indiquera de plus le nombre de pas que le joueur
        a eu besoin pour finir le niveau.
        """
        niveau=self.ui.Choix_Niveau.value()
        if self.gagne(plateau)[0]==True:
            self.widget = QMainWindow(self)
            self.widget.setCentralWidget(QWidget(self.widget))
            self.widget.setWindowTitle("Victoire")
            label=QLabel("Felicitation, vous avez réussi le niveau "+ str(niveau)+" et ceci en "+str(self.nbr_pas)+" pas.\n Passez au niveau suivant pour plus de difficulté ou tentez de battre votre record sur ce niveau!")
            mainLayout=QVBoxLayout(self.widget.centralWidget())
            mainLayout.addWidget(label)
            self.widget.show()

    def genere_plateau(self):
        """
        Cette méthode réalise la création du plateau de Jeu. Pour cela, on lit la 
        taille de la grille choisie par le joueur et on ouvre le fichier texte 
        correspondant. Ensuite on utilise les classe sPlateau_jeu et Joueur_case
        qui vont nous créer notre plateau de jeu (ici que du sol et des murs).
        Le plateau 2 va nous servir pour le retour.
        """
        Choix=self.ui.Choix_Niveau.value()#On récupère le choix du Joueur
        self.plateau=Joueur_case(Plateau_jeu('nivo'+str(Choix)+'.txt')).plateau
        self.plateau2=Joueur_case(Plateau_jeu('nivo'+str(Choix)+'.txt')).plateau2
        self.nbr_pas=0#On réinitialise le nombre de pas car on lance une grille vierge
        self.nbr_caisse=self.gagne(self.plateau)[2] #On récupère le nombre de caisse initial
        self.ui.lcd_pas.display(self.nbr_pas)#On affiche les nombres de pas et de caisse sur les écrans LCD en haut à droite
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.aide="desactive" #L'aide est désactivée
        self.ui.centralwidget.update()
        
    def Aide_joueur(self):
        """
        Cette méthode est une méthode qui va permettre au joueur de faire le meilleur score dans
        les différents niveaux. En effet, elle va montrer au joueur le plus court chemin entre 
        lui-même et la caisse la plus proche. Pour cela on utilise la methode process() de la
        classe Aide_joueur(plateau) qui va nous renvoyer le chemin (Algorithme A*), il suffira juste de lui 
        associer une image lors du dessin. On modifie la variable aide pour spécifier qu'on a 
        demandé de l'aide.
        """
        A=Aide_Joueur(self.plateau)
        A.process()
        self.path=A.L
        self.aide="active"
         
        

    def Mouvements_haut(self):
        """
        Dans ces méthodes, on fait bouger notre plateau. On s'assure tout d'abord que le bouton
        Play a bien été enfoncé auparavant puis on va utiliser la méthode bouger_joueur_mouvement()
        de la classe Joueur_case(). On va donc actualiser notre plateau avec le bon mouvement.
        Ensuite on ajoute un au nombre de pas effectués qu'on actualise sur l'écran LCD.
        Enfin, on regarde si on a gagné, ie qu'il n'ya plus de caisses à ranger, avec la 
        méthode gagne(plateau). Si c'est le cas on affiche le message de Victoire à l'aide de la
        méthode Victoire()
        """
        j=Joueur_case(self.plateau)
        self.a=j.plateau2.copy()#Pour le retour en arrière
        j.bouger_joueur_haut() #On actualise le plateau de jeu
        self.nbr_pas+=1#on augmente le nombre de pas
        self.ui.lcd_pas.display(self.nbr_pas)
        self.nbr_caisse=self.gagne(self.plateau)[2]#on actualise le nombre de caisse
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.victoire(self.plateau)#S'il n'y plus de caisses à ranger alors on affiche le message de victoire
        self.bloquage_caisse(self.plateau)#Si une caisse est bloquée, on affiche le game over
        self.aide="desactive"#On se déplace donc on désactive l'aide
        self.ui.centralwidget.update()


    def Mouvements_droit(self):
        j=Joueur_case(self.plateau)
        self.a=j.plateau2.copy()#Pour le retour en arrière
        j.bouger_joueur_droit()
        self.nbr_pas+=1
        self.ui.lcd_pas.display(self.nbr_pas)
        self.nbr_caisse=self.gagne(self.plateau)[2]
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.victoire(self.plateau)
        self.bloquage_caisse(self.plateau)
        self.aide="desactive"
        self.ui.centralwidget.update()
    
    def Mouvements_bas(self):
        j=Joueur_case(self.plateau)
        self.a=j.plateau2.copy()#Pour le retour en arrière
        j.bouger_joueur_bas()
        self.nbr_pas+=1
        self.ui.lcd_pas.display(self.nbr_pas)
        self.nbr_caisse=self.gagne(self.plateau)[2]
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.victoire(self.plateau)
        self.bloquage_caisse(self.plateau)
        self.aide="desactive"
        self.ui.centralwidget.update()
    
    def Mouvements_gauche(self):
        j=Joueur_case(self.plateau)
        self.a=j.plateau2.copy()#Pour le retour en arrière
        j.bouger_joueur_gauche()        
        self.nbr_pas+=1
        self.ui.lcd_pas.display(self.nbr_pas)
        self.nbr_caisse=self.gagne(self.plateau)[2]
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.victoire(self.plateau)
        self.bloquage_caisse(self.plateau)
        self.aide="desactive"
        self.ui.centralwidget.update()
    
    def retour(self):
        self.plateau=self.a
        self.nbr_pas+=1 #On a fait un pas en arrière
        self.ui.lcd_pas.display(self.nbr_pas)
        self.nbr_caisse=self.gagne(self.a)[2]
        self.ui.lcd_caisse.display(self.nbr_caisse)
        self.aide="desactive"
        self.ui.centralwidget.update()
        
    def gagne(self,plateau): 
        """
        Permet de stopper le niveau lorsque le joueur a déposer toutes les caisses sur les cibles.
        Cette fonction sert aussi à indiquer dans la console le nombre de caisse qu'il lui reste à ranger.
        """        
        self.xm=self.plateau.shape[0]
        self.ym=self.plateau.shape[1]
        win= True
        caisse_a_ranger=0
        for i in range(self.xm):
            for j in range(self.ym):
                if self.plateau[i,j]==6:#self[i,j] est la case de coodronée i,j du plateau de jeu
                    win=False
                    caisse_a_ranger+=1
        return (win, "Il reste {0} caisses à ranger.".format(caisse_a_ranger),caisse_a_ranger)   
        
    
    def keyPressEvent(self, event):
        """
        Cette méthode permet à l'utilisateur de pouvoir utiliser son clavier en complement des
        boutons directionnels sur l'écran. A chaque appui sur la touche correspondante, on 
        lance une méthode de déplacement
        """
        if event.key() == QtCore.Qt.Key_Up:
            self.Mouvements_haut()

        if event.key() == QtCore.Qt.Key_Left:
            self.Mouvements_gauche()

        if event.key() == QtCore.Qt.Key_Down:
            self.Mouvements_bas()

        if event.key() == QtCore.Qt.Key_Right:  
            self.Mouvements_droit()

        
    def drawecosysteme(self, *args):
        """
        Cette méthode nous permet de déssinner notre plateau de Jeu. Premièrement, on regarde 
        le choix fait par l'utilisateur et on adapte la taille de la grille en fonction du nombre 
        d'élément composant le plateau avec la variable taille.
        Ensuite, on charge les images correspondantes aux différents composants du jeu puis on 
        parcourt notre plateau en dessinnant, pour chaque composant, l'image qui lui est associée.
        Pour ce faire, on va venir dessinner un carré dont le sommet en haut à gauche est la 
        l'indice du composant dans le plateau modulo la variable taille.
        De plus, il faut ici dissocier si on a actvé l'aide ou non. Si c'est le cas, il faut 
        afficher le chemin qui correspond à la méthode Aide_joueur().
        """
        if self.ui.Choix_Niveau.value()==0:#On regarde le choix du joueur
            self.taille=69
        elif self.ui.Choix_Niveau.value()==1:
            self.taille=42
        elif self.ui.Choix_Niveau.value()==2:
            self.taille=46
        elif self.ui.Choix_Niveau.value()==3:
            self.taille=44
        elif self.ui.Choix_Niveau.value()==4:
            self.taille=34
        self.ecopainter.begin(self.ui.Conteneur)#Outils pour le dessin
        self.ecopainter.setPen(QtCore.Qt.red)
        largeur=self.plateau.shape[0]
        hauteur=self.plateau.shape[1]
        image1 = QtGui.QImage("homme50x50.png")#On charge les images
        image2 = QtGui.QImage("sol50x50.png")
        image3 = QtGui.QImage("mur50x50.png")
        image4 = QtGui.QImage("goal50x50.png")
        image5 = QtGui.QImage("caisse50x50.png")
        image6 = QtGui.QImage("caisseok50x50.png")
        image7 = QtGui.QImage("path50x50.png")
        haut,larg=140,100#on se décale un peu du bords pour plus de visibilité
        for x in range (largeur):
            for y in range(hauteur):#Enfin, on dessinne !
                if self.aide=="desactive":#Si l'aide n'est pas activée on fait comme d'habitude 
                    if self.plateau[x,y] == 5:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille,self.taille),image1)
                    elif self.plateau[x,y] == 4:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image2)
                    elif self.plateau[x,y] == 1:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image3)
                    elif self.plateau[x,y] == 8:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image4)
                    elif self.plateau[x,y] == 6:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image5)
                    elif self.plateau[x,y] == 0:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image6)
                    elif self.plateau[x,y] == 9:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image1)
                
                elif self.aide=="active":#SI l'aide est activée, on dessinne le chemin correspondant
                    if self.plateau[x,y] == 5:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille,self.taille),image1)
                    elif self.plateau[x,y] == 4 and (x,y) not in self.path:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image2)
                    elif self.plateau[x,y] == 4 and (x,y)  in self.path:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image7)
                    elif self.plateau[x,y] == 1:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image3)
                    elif self.plateau[x,y] == 8:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image4)
                    elif self.plateau[x,y] == 6:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image5)
                    elif self.plateau[x,y] == 0:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image6)
                    elif self.plateau[x,y] == 9:
                        self.ecopainter.drawImage(QtCore.QRect(larg, haut, self.taille, self.taille),image1)
                larg=larg+self.taille
            haut=haut+self.taille
            larg=100
        self.ecopainter.end()#On stop le processus de dessin jusqu'à la prochaine action
        

        
if __name__ == "__main__":
#    app = QApplication(sys.argv)
    window = Jeu()
    window.show()
    app.exec_()