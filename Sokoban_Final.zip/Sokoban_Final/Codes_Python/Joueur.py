# -*- coding: utf-8 -*-
"""
Created on Wed May  9 18:44:07 2018

@author: SYSTEM
"""


"""
La classe Joueur_case est celle faisant fonctionner tout le programme. Elle récupère le plateau
de Jeu créé par la classe Plateau_Jeu pour ensuite faire bouger notre joueur au sein de ce plateau
En effet, on récupère tout d'abords les coordonnées du Joueur puis à l'aide des différentes méthodes
de mouvements, on fait déplaccer le joueur au sein de notre plateau de Jeu.
Le code n'est pas optimal car pour les vérifcation on aurait pu utiliser une liste [x,y,dx,dy]
permettant de recenser les différents types de mouvement plutôt que de faire des copier-collers"""
class Joueur_case(object):
    
    def __init__(self,plateau):#On reprend directement le plateau créé par la classe Plateau_jeu
        self.plateau=plateau
        self.plateau2=plateau#Pour le retour en arrière (sauvegarde)
        for i in range(self.plateau.shape[0]):
            for j in range(self.plateau.shape[1]):
                if self.plateau[i][j]==5 or self.plateau[i][j]==9:
                    self.__coords= (i,j)
    @property
    def coords(self):
        """
        coords: tuple
            Les coordonnées du joueur sur le plateau de jeu
        """
        return self.__coords  
    
    @coords.setter
    def coords(self, nouv_coords):
        """
        Met à jour les coordonnées du joueur.
    
        Paramètres
        ----------
        nouv_coords : tuple représentant les coordonnées auquelles 
                      le joueur essaie de se rendre.
        """
        x, y = nouv_coords
        self.__coords = (x, y)    
    
     
    @property
    def y(self):
        """
        x: nombre entier
            Abscisse du joueur
        """
        return self.coords[1]

    @property
    def x(self):
        """
        y: nombre entier
            ordonnee du Joueur
        """
        return self.coords[0]
    
    def bouger_joueur_haut(self):
        """
        Méthode servant à faire bouger le joueur lorsqu'il se déplace vers le haut, on vérifie 
        tout un tas de conditions, suivant l'environnement du joueur, avant de le faire bouger.
        Par exemple, s'il n'y a pas 2caisses à suivre, un mur derrière la caisse...
        Enfin quand tout est bon on actualise le plateau.
        """
        if self.plateau[self.x-1,self.y]==4: #Si la case vers laquelle on veut aller est une case sol, on peut alors bouger
            if self.plateau[self.coords]==9:
                self.plateau[self.coords]=8
            else:
                self.plateau[self.coords]=4
            self.plateau[self.x-1,self.y]=5
            self.coords=self.x-1,self.y
        
        elif self.plateau[self.x-1,self.y]==1: #Si la case vers laquelle on veut aller est une case mur, on ne peut pas bouger la caisse
            print('mouvement impossible')
        
        elif self.plateau[self.x-1,self.y]==8:#Si la case vers laquelle on veut aller est une case cible
            if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
            else:
                    self.plateau[self.coords]=4                    
            self.plateau[self.x-1,self.y]=9
            self.coords=self.x-1,self.y
            
        elif self.plateau[self.x-1,self.y]==6: #Si la case vers laquelle on veut aller est une case caisse, il faut déplacer le joueur et la caisse 
            #On regarde la case après la caisse pour savoir si on peut bouger le joueur et la caisse dans cette direction
            if self.plateau[self.x-2,self.y]==4: #Si cette case en question est une case sol, on peut donc bouger la caisse dans cette direction 
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x-2,self.y]=6
                self.plateau[self.x-1,self.y]=5
                self.coords=self.x-1,self.y
                
            elif self.plateau[self.x-2,self.y]==8:#Si cette case en question est une case cible, on peut donc bouger la caisse dans cette direction 
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4                        
                self.plateau[self.x-2,self.y]=0
                self.plateau[self.x-1,self.y]=5
                self.coords=self.x-1,self.y
                print('Une caisse a atteint une cible')
                
        elif self.plateau[self.x-1,self.y]==0: #Si la case vers laquelle on veut aller est une cible occupée, on peut quand même bouger la caisse
             
            if self.plateau[self.x-2,self.y]==4: #Si cette case en question est une case sol, on peut donc bouger la caisse dans cette direction 
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4                        
                self.plateau[self.x-2,self.y]=6
                self.plateau[self.x-1,self.y]=9
                self.coords=self.x-1,self.y
                
            elif self.plateau[self.x-2,self.y]==8:#Si cette case en question est une case cible, on peut donc bouger la caisse dans cette direction 
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x-2,self.y]=0
                self.plateau[self.x-1,self.y]=9
                self.coords=self.x-1,self.y
                
            elif self.plateau[self.x-2,self.y]==1 or self.plateau[self.x-2,self.y]==6:#Si cette case en question est une case caisse ou une case mur, on ne peut pas bouger la caisse dans cette direction 
                print('mouvement impossible')

                        
    def bouger_joueur_droit(self):
            if self.plateau[self.x,self.y+1]==4:#Si la case vers laquelle on veut aller est une case sol, on peut alors bouger la caisse
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x,self.y+1]=5
                self.coords=self.x,self.y+1
                
            elif self.plateau[self.x,self.y+1]==1:#Si la case vers laquelle on veut aller est une case mur, on ne peut pas bouger la caisse
                print('mouvement impossible')
                
            elif self.plateau[self.x,self.y+1]==8:#Si la case vers laquelle on veut aller est une case cible
                if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                else:
                        self.plateau[self.coords]=4                    
                self.plateau[self.x,self.y+1]=9
                self.coords=self.x,self.y+1
                
            elif self.plateau[self.x,self.y+1]==6:#Si la case vers laquelle on veut aller est une case caisse, il faut déplacer le joueur et la caisse 
                #On regarde la case après la caisse pour savoir si on peut bouger le joueur et la caisse dans cette direction
                if self.plateau[self.x,self.y+2]==4:#Si cette case en question est une case sol, on peut donc bouger la caisse dans cette direction 
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x,self.y+2]=6
                    self.plateau[self.x,self.y+1]=5
                    self.coords=self.x,self.y+1
                    
                elif self.plateau[self.x,self.y+2]==8: #Si cette case en question est une case cible, on peut donc bouger la caisse dans cette direction 
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x,self.y+2]=0
                    self.plateau[self.x,self.y+1]=5
                    self.coords=self.x,self.y+1
                    print('Une caisse a atteint une cible')
                    
            elif self.plateau[self.x,self.y+1]==0: #Si la case vers laquelle on veut aller est une cible occupée, on peut quand même bouger la caisse
                if self.plateau[self.x,self.y+2]==4:#Si cette case en question est une case sol, on peut donc bouger la caisse dans cette direction 
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x,self.y+2]=6
                    self.plateau[self.x,self.y+1]=9
                    self.coords=self.x,self.y+1
                    
                elif self.plateau[self.x,self.y+2]==8: #Si cette case en question est une case cible, on peut donc bouger la caisse dans cette direction 
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4                        
                    self.plateau[self.x,self.y+2]=0
                    self.plateau[self.x,self.y+1]=9
                    self.coords=self.x,self.y+1
                    print('Une caisse a atteint une cible')
                    
                elif self.plateau[self.x,self.y+2]==1 or self.plateau[self.x,self.y+2]==6:#Si cette case en question est une case caisse ou une case mur, on ne peut pas bouger la caisse dans cette direction 
                    print('mouvement impossible')  
#                    
#      
    def bouger_joueur_bas(self):
            if self.plateau[self.x+1,self.y]==4:#case sol
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x+1,self.y]=5
                self.coords=self.x+1,self.y
                
            elif self.plateau[self.x+1,self.y]==1:#case mur
                print('mouvement impossible')
                
                
            elif self.plateau[self.x+1,self.y]==8:#Si la case vers laquelle on veut aller est une case cible
                if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                else:
                        self.plateau[self.coords]=4                    
                self.plateau[self.x+1,self.y]=9
                self.coords=self.x+1,self.y   
                
            elif self.plateau[self.x+1,self.y]==6:#case caisse
                if self.plateau[self.x+2,self.y]==4:#on deplace la caisse sur le sol
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x+2,self.y]=6
                    self.plateau[self.x+1,self.y]=5
                    self.coords=self.x+1,self.y
                    
                elif self.plateau[self.x+2,self.y]==8:#On deplace la caisse sur une cible
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x+2,self.y]=0
                    self.plateau[self.x+1,self.y]=5
                    self.coords=self.x+1,self.y
                    print('la caisse a bien atteint sa cible')
                    
            elif self.plateau[self.x+1,self.y]==0: #Si la case vers laquelle on veut aller est une cible occupée, on peut quand même bouger la caisse
                 
                if self.plateau[self.x+2,self.y]==4: #Si cette case en question est une case sol, on peut donc bouger la caisse dans cette direction 
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x+2,self.y]=6
                    self.plateau[self.x+1,self.y]=9
                    self.coords=self.x+1,self.y
                    
                elif self.plateau[self.x+2,self.y]==8:#Si cette case en question est une case cible, on peut donc bouger la caisse dans cette direction 
                    if self.plateau[self.coords]==9:
                        self.plateau[self.coords]=8
                    else:
                        self.plateau[self.coords]=4
                    self.plateau[self.x+2,self.y]=0
                    self.plateau[self.x+1,self.y]=9
                    self.coords=self.x+1,self.y
                    
                elif self.plateau[self.x+2,self.y]==1 or self.plateau[self.x+2,self.y]==6:#on peut pas déplacer la caisse
                    print('mouvement impossible')     
#    
#                    
    def bouger_joueur_gauche(self):
        if self.plateau[self.x,self.y-1]==4:#case sol
            if self.plateau[self.coords]==9:
                self.plateau[self.coords]=8
            else:
                self.plateau[self.coords]=4
            self.plateau[self.x,self.y-1]=5
            self.coords=self.x,self.y-1
            
        elif self.plateau[self.x,self.y-1]==1:#case mur
            print('mouvement impossible')
            
        elif self.plateau[self.x,self.y-1]==8:#Si la case vers laquelle on veut aller est une case cible
            if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
            else:
                    self.plateau[self.coords]=4                    
            self.plateau[self.x,self.y-1]=9
            self.coords=self.x,self.y-1
            
        elif self.plateau[self.x,self.y-1]==6:#case caisse
            if self.plateau[self.x,self.y-2]==4:#on pousse vers une case sol
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4                        
                self.plateau[self.x,self.y-2]=6
                self.plateau[self.x,self.y-1]=5
                self.coords=self.x,self.y-1
                
            elif self.plateau[self.x,self.y-2]==8:#on pousse vers une case cible
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x,self.y-2]=0
                self.plateau[self.x,self.y-1]=5
                self.coords=self.x,self.y-1
                print('la caisse a bien atteint sa cible')
                
        elif self.plateau[self.x,self.y-1]==0: #Si la case vers laquelle on veut aller est une cible occupée, on peut quand même bouger la caisse
             
            if self.plateau[self.x,self.y-2]==4:#on pousse vers une case sol
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x,self.y-2]=6
                self.plateau[self.x,self.y-1]=9
                self.coords=self.x,self.y-1
                
            elif self.plateau[self.x,self.y-2]==8:#on pousse vers une case cible
                if self.plateau[self.coords]==9:
                    self.plateau[self.coords]=8
                else:
                    self.plateau[self.coords]=4
                self.plateau[self.x,self.y-2]=0
                self.plateau[self.x,self.y-1]=9
                self.coords=self.x,self.y-1
                
            elif self.plateau[self.x-2,self.y]==1 or self.plateau[self.x-2,self.y]==6:
                print('mouvement impossible')
#                        

            print(self.plateau)