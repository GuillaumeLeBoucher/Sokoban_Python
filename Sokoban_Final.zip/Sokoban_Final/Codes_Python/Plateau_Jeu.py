# -*- coding: utf-8 -*-
"""
Created on Wed May  9 18:41:47 2018

@author: SYSTEM
"""

import numpy as np

"""
Ce module contient la définition de la classe principale servant à géner un plateau de jeu
sous la forme qui nous convient: un np.array. C'est la toute première classe que nous avons 
implémenté, les commandes et les aides servaient lorsque nous avons utilisé notre programme
uniquement dans le terminal. Il ne faut donc plus en tenir compte, elles ne sont présente qu'a titre
indicatif.
"""
     
"Commandes  Jeu"

# 8 : Déplacement du joueur vers le haut  
# 4 : Déplacement du joueur vers la gauche
# 6 : Déplacement du joueur vers la droite
# 2 : Déplacement du joueur vers le bas

" Aides"
 
# Joueur : 5
# Sol : 4
# Cible: 8
# Caisse : 6
# Mur : 1
#Caisse sur une cible: 0
#Joueur sur une cible: 9

 
class Plateau_jeu(np.ndarray):

    def __new__(cls, filename): #Création et initailisation d'un ndarray à la bonne taille!!
        #ouvrir fichier 
        f=open(filename,'r')
        t=f.readlines()
        D=[]
        for i in range(0,len(t)):
            R=list(t[i])
            D.append(R)
        k=0
        for i in D:
            k=max(k,len(i))
        xmax=len(D)
        ymax=k
        for i in D:
            while len(i)<ymax:
                i.append(' ')
        new_obj = super(Plateau_jeu, cls).__new__(cls, (xmax, ymax), dtype=int)
        new_obj.xm=xmax
        new_obj.ym=ymax
        new_obj.D=D
        return new_obj
    
    def __init__(self, filename):#Ici, on va transformer notr fichier XSB dans un format plus lisible
        for i in range(self.xm):
            for j in range(self.ym):
                if self.D[i][j]==' ':
                    self[i][j]=4
                if self.D[i][j]=='#':
                    self[i][j]=1
                if self.D[i][j]=='@':
                    self[i][j]=5
                if self.D[i][j]=='$':
                    self[i][j]=6
                if self.D[i][j]=='.':
                    self[i][j]=8
                if self.D[i][j]=='\n':
                    self[i][j]=4
        print(self) #Pour afficher le plateau à chaque fois
    
    def gagne(self): #Permet de stopper le niveau lorsque le joueur a déposer toutes les caisses sur les cibles.
        #Cette fonction sert aussi à indiquer au joueur le nombre de caisse qu'il lui reste à ranger
        win= True
        caisse_a_ranger=0
        for i in range(self.xm):
            for j in range(self.ym):
                if self[i,j]==6:#self[i,j] est la case de coodronée i,j du plateau de jeu
                    win=False
                    caisse_a_ranger+=1
        return (win, "Il reste {0} caisses à ranger.".format(caisse_a_ranger),caisse_a_ranger)

