Afin de lancer notre, il faut lancer le script Python s'intitulant Main.py.

A cause d'un soucis d'installation de Qt pendant les vacances, nous n'avons pas été en mesure de fournir
un code code sous Qt5 mais uniquement un code sous Qt4. Nous sommes sincèrement désolé pour ce désagrément 
et nous eespérons que cela ne vous empêchera pas de lancer notre programme.

Une fois que le Main a été lancé, vous pouvez choisir soit de jouer ou d'éditer à l'aide de l'interface graphique.
Cependant, nous n'avons pas eu le temps pour mettre point une commande "Retour au menu principal", il faudra donc
relancer le main pour pouvoir acceder à l'autre partie du programme.

Dans chacune des perties (Jeu ou Édition), vous pouvez retrouver dans le menu les rêgles propre à notre jeu et à notre interface graphique. Merci de les consulter avant de débuter le Jeu.

Merci et Bon Jeu !



